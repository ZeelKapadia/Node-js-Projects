const express = require('express');
const http = require('http');
const { Server } = require('socket.io');
const Redis = require('ioredis');
const app = express();
const server = http.createServer(app);
const io = new Server(server);
const redis = new Redis();
// Subscribe to a Redis channel for real-time chat
const redisChannel = 'realtime_chat';
const redisSubscriber = new Redis();
redisSubscriber.subscribe(redisChannel);
// WebSocket setup
io.on('connection', (socket) => {
    console.log('User connected');
    // Listen for incoming chat messages
    socket.on('chat message', (msg) => {
        // Broadcast the message to all connected clients
        io.emit('chat message', msg);
        // Publish the message to the Redis channel for cross-server communication
        redisPublisher.publish(redisChannel, msg);
    });
    // Handle disconnection
    socket.on('disconnect', () => {
        console.log('User disconnected');
    });
});
// Listen to Redis messages and broadcast them to WebSocket clients
redisSubscriber.on('message', (channel, message) => {
    io.emit('chat message', message);
});
server.listen(3000, () => {
    console.log('Server listening on *:3000');
});