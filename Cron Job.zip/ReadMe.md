Schedule CRON jobs in Node.js

To schedule cron jobs in Node.js, you can use a library called “node-cron”. This library allows you to schedule and run cron jobs within your Node.js application.

A step-by-step guide along with a code example to help you set up and schedule cron jobs using “node-cron”:

1. **Initialize a Node.js project:**
   Start by creating a new Node.js project or navigate to an existing one.

2. **Install the `node-cron` package:**
   Open a terminal and run the following command to install the “node-cron” package:

npm install node-cron

3. **Import the “node-cron” module:**
   In your Node.js script, import the node-cron module:

const cron = require('node-cron');

4. **Define a cron job:**
   Create a function that you want to run on a specified schedule using cron syntax. For example, let’s create a simple function that logs a message:

function logMessage() {
console.log('Cron job executed at:', new Date().toLocaleString());
}

5.  **Schedule the cron job:**
    Use “cron.schedule” to schedule the function to run according to a cron expression. Here, we’ll schedule the function to run every minute:

// Schedule the cron job to run every minute
cron.schedule('\* \* \* \* \*', () => {
logMessage();
});

In the cron expression, each asterisk represents a different time unit (minute, hour, day of the month, month, day of the week). Here, we use asterisks to represent “every” for each unit, so the cron job runs every minute.

6.  **Run the Node.js script:**
    Start the Node.js script using the “node” command:

node your_script.js

Replace “your_script.js”with the name of your JavaScript file.

Here’s the complete example code:

const cron = require('node-cron');
function logMessage() {
console.log('Cron job executed at:', new Date().toLocaleString());
}
// Schedule the cron job to run every minute
cron.schedule('\* \* \* \* \*', () => {
logMessage();
});

This example will log a message every minute. You can adjust the cron expression to suit your specific scheduling needs.
