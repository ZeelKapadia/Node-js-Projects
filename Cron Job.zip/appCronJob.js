// Import required modules
const express = require('express');
const cron = require('node-cron');

// Create an Express application
const app = express();
const port = 3000; // Port number on which the server will run

// Define a sample data array (for demonstration purposes)
const books = [
    { id: 1, title: 'Harry Potter', author: 'J.K. Rowling' },
    { id: 2, title: 'Lord of the Rings', author: 'J.R.R. Tolkien' },
    { id: 3, title: 'To Kill a Mockingbird', author: 'Harper Lee' }
];

// Define a route to get all books
app.get('/api/books', (req, res) => {
    res.json(books); // Return the books array as JSON
});

// Define a route to get a single book by ID
app.get('/api/books/:id', (req, res) => {
    const id = parseInt(req.params.id); // Extract the ID from the request URL
    const book = books.find(book => book.id === id); // Find the book with the given ID
    if (book) {
        res.json(book); // Return the book as JSON if found
    } else {
        res.status(404).send('Book not found'); // Return a 404 error if book not found
    }
});

// Schedule a cron job to run every minute
cron.schedule('* * * * * *', () => {
    console.log('This cron job runs every second');

    // Add your task here, such as sending an email, processing data, etc.
});

// Start the server
app.listen(port, () => {
    console.log(`Server is listening on port ${port}`);
});
