const express = require('express');

const app = express();
const port = 3000; // Port number on which the server will run

app.listen(port, () => {
    getUserData(1)
    console.log(`Server is listening on port ${port}`);
});

// Example: Implementing Object Caching with Redis in Node.js:
const Redis = require('ioredis');
const redis = new Redis();

// Function to fetch user data
async function fetchUserData(userId) {
    // Simulate fetching data from a database
    const data = { id: userId, name: 'John Doe', email: 'john@example.com' };
    return data;
}

async function getUserData(userId) {
    const cacheKey = `user:${userId}`;
    const cachedData = await redis.get(cacheKey);
    if (cachedData) {
        // Data found in cache, return it
        return JSON.parse(cachedData);
    } else {
        // Data not found in cache, fetch and store it
        const userData = await fetchUserData(userId);
        await redis.set(cacheKey, JSON.stringify(userData), 'ex', 3600); // Cache for 1 hour
        return userData;
    }
}